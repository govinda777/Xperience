import{m as l}from"./core-DZfByqaw.js";import"./wallet-SUlNNbLh.js";import"./vendor-BfOSbBEK.js";import"./router-BBtlhYrD.js";import"valtio/vanilla";import"valtio/vanilla/utils";import"./index-72GiH3Xg.js";import"./analytics-CIB60-R_.js";const o=l`<svg fill="none" viewBox="0 0 16 16">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M14.54 11.04a1 1 0 0 1-1.41 0L8 5.92l-5.13 5.12a1 1 0 1 1-1.41-1.41l5.83-5.84a1 1 0 0 1 1.42 0l5.83 5.84a1 1 0 0 1 0 1.41Z"
    clip-rule="evenodd"
  />
</svg>`;export{o as chevronTopSvg};
