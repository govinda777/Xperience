import{m as o}from"./core-DZfByqaw.js";import"./wallet-SUlNNbLh.js";import"./vendor-BfOSbBEK.js";import"./router-BBtlhYrD.js";import"valtio/vanilla";import"valtio/vanilla/utils";import"./index-72GiH3Xg.js";import"./analytics-CIB60-R_.js";const i=o`<svg fill="none" viewBox="0 0 24 24">
  <path
    style="fill: var(--wui-color-accent-100);"
    d="M10.2 6.6a3.6 3.6 0 1 1-7.2 0 3.6 3.6 0 0 1 7.2 0ZM21 6.6a3.6 3.6 0 1 1-7.2 0 3.6 3.6 0 0 1 7.2 0ZM10.2 17.4a3.6 3.6 0 1 1-7.2 0 3.6 3.6 0 0 1 7.2 0ZM21 17.4a3.6 3.6 0 1 1-7.2 0 3.6 3.6 0 0 1 7.2 0Z"
  />
</svg>`;export{i as allWalletsSvg};
